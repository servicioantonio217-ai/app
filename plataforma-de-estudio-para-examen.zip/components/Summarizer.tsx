
import React, { useState, useCallback } from 'react';
import { generateSummary } from '../services/geminiService';
import Spinner from './common/Spinner';
import Card from './common/Card';

const Summarizer: React.FC = () => {
    const [text, setText] = useState('');
    const [summary, setSummary] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleGenerate = useCallback(async () => {
        if (!text.trim()) {
            setError("Por favor, introduce un texto o tema.");
            return;
        }
        setIsLoading(true);
        setError(null);
        setSummary(null);
        try {
            const result = await generateSummary(text);
            setSummary(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : "Ocurrió un error desconocido.");
        } finally {
            setIsLoading(false);
        }
    }, [text]);

    // Format summary with bullet points
    const formattedSummary = summary
        ? summary.split(/(\*|-|\d\.)/).filter(s => s.trim() && !'*-'.includes(s.trim())).map((item, index) => (
            <li key={index} className="mb-2 text-slate-700">{item.trim()}</li>
        ))
        : null;


    return (
        <Card className="w-full max-w-4xl mx-auto">
            <div className="flex flex-col gap-4 mb-6">
                <textarea
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    placeholder="Pega un texto largo aquí o escribe un tema para resumir..."
                    className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition h-40 resize-y"
                    disabled={isLoading}
                />
                <button
                    onClick={handleGenerate}
                    disabled={isLoading || !text.trim()}
                    className="w-full bg-indigo-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-indigo-700 transition-colors disabled:bg-indigo-300 disabled:cursor-not-allowed"
                >
                    {isLoading ? "Generando..." : "Generar Resumen"}
                </button>
            </div>

            {error && <p className="text-red-500 text-center my-4">{error}</p>}
            
            {isLoading && <Spinner />}

            {summary && (
                <div className="mt-8">
                    <h3 className="text-2xl font-bold text-slate-700 mb-4">Resumen de Puntos Clave</h3>
                    <div className="bg-slate-50 p-6 rounded-lg">
                        <ul className="list-disc list-inside space-y-2">
                           {formattedSummary}
                        </ul>
                    </div>
                </div>
            )}
        </Card>
    );
};

export default Summarizer;
