
import React, { useState, useCallback } from 'react';
import { QuizQuestion } from '../types';
import { generateQuiz } from '../services/geminiService';
import Spinner from './common/Spinner';
import Card from './common/Card';

const QuizGenerator: React.FC = () => {
    const [topic, setTopic] = useState('');
    const [questions, setQuestions] = useState<QuizQuestion[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [selectedAnswers, setSelectedAnswers] = useState<Record<number, string>>({});
    const [isSubmitted, setIsSubmitted] = useState(false);
    const [score, setScore] = useState(0);

    const handleGenerate = useCallback(async () => {
        if (!topic.trim()) {
            setError("Por favor, introduce un tema.");
            return;
        }
        setIsLoading(true);
        setError(null);
        setQuestions([]);
        setSelectedAnswers({});
        setIsSubmitted(false);
        setScore(0);
        try {
            const result = await generateQuiz(topic);
            setQuestions(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : "Ocurrió un error desconocido.");
        } finally {
            setIsLoading(false);
        }
    }, [topic]);

    const handleAnswerSelect = (questionIndex: number, answer: string) => {
        if (isSubmitted) return;
        setSelectedAnswers(prev => ({ ...prev, [questionIndex]: answer }));
    };

    const handleSubmit = () => {
        let currentScore = 0;
        questions.forEach((q, index) => {
            if (selectedAnswers[index] === q.respuestaCorrecta) {
                currentScore++;
            }
        });
        setScore(currentScore);
        setIsSubmitted(true);
    };

    const getOptionClasses = (questionIndex: number, option: string) => {
        if (!isSubmitted) {
            return selectedAnswers[questionIndex] === option
                ? 'bg-indigo-200 border-indigo-500'
                : 'bg-white border-slate-300 hover:bg-slate-100';
        }

        const isCorrectAnswer = option === questions[questionIndex].respuestaCorrecta;
        const isSelectedAnswer = selectedAnswers[questionIndex] === option;

        if (isCorrectAnswer) {
            return 'bg-green-100 border-green-500 text-green-800 font-semibold';
        }
        if (isSelectedAnswer && !isCorrectAnswer) {
            return 'bg-red-100 border-red-500 text-red-800';
        }
        return 'bg-white border-slate-300 opacity-70';
    };

    return (
        <Card className="w-full max-w-4xl mx-auto">
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
                <input
                    type="text"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    placeholder="Ej: El Sistema Solar"
                    className="flex-grow p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                    disabled={isLoading}
                />
                <button
                    onClick={handleGenerate}
                    disabled={isLoading || !topic.trim()}
                    className="bg-indigo-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-indigo-700 transition-colors disabled:bg-indigo-300 disabled:cursor-not-allowed"
                >
                    {isLoading ? "Generando..." : "Generar Cuestionario"}
                </button>
            </div>

            {error && <p className="text-red-500 text-center my-4">{error}</p>}
            
            {isLoading && <Spinner />}

            {questions.length > 0 && (
                <div className="space-y-8 mt-8">
                    {questions.map((q, qIndex) => (
                        <div key={qIndex}>
                            <p className="text-lg font-semibold text-slate-800 mb-4">{qIndex + 1}. {q.pregunta}</p>
                            <div className="space-y-3">
                                {q.opciones.map((option, oIndex) => (
                                    <button
                                        key={oIndex}
                                        onClick={() => handleAnswerSelect(qIndex, option)}
                                        disabled={isSubmitted}
                                        className={`w-full text-left p-3 border-2 rounded-lg transition-colors duration-200 ${getOptionClasses(qIndex, option)}`}
                                    >
                                        {option}
                                    </button>
                                ))}
                            </div>
                        </div>
                    ))}
                    <div className="text-center pt-4">
                        {isSubmitted ? (
                            <div className="text-2xl font-bold p-4 rounded-lg bg-indigo-100 text-indigo-800">
                                Tu puntuación: {score} de {questions.length}
                            </div>
                        ) : (
                            <button
                                onClick={handleSubmit}
                                disabled={Object.keys(selectedAnswers).length !== questions.length}
                                className="bg-green-600 text-white font-bold py-3 px-8 rounded-lg hover:bg-green-700 transition-colors disabled:bg-green-300 disabled:cursor-not-allowed"
                            >
                                Corregir
                            </button>
                        )}
                    </div>
                </div>
            )}
        </Card>
    );
};

export default QuizGenerator;
