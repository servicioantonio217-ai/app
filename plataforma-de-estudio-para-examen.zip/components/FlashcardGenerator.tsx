
import React, { useState, useCallback } from 'react';
import { Flashcard } from '../types';
import { generateFlashcards } from '../services/geminiService';
import Spinner from './common/Spinner';
import Card from './common/Card';

const FlashcardView: React.FC<{ card: Flashcard }> = ({ card }) => {
    const [isFlipped, setIsFlipped] = useState(false);

    return (
        <div className="w-full h-56 perspective-1000" onClick={() => setIsFlipped(!isFlipped)}>
            <div
                className={`relative w-full h-full transform-style-3d transition-transform duration-700 ${isFlipped ? 'rotate-y-180' : ''}`}
            >
                {/* Front of the card */}
                <div className="absolute w-full h-full backface-hidden bg-white rounded-xl shadow-md flex items-center justify-center p-6 border-2 border-indigo-200">
                    <p className="text-xl font-semibold text-slate-800 text-center">{card.pregunta}</p>
                </div>
                {/* Back of the card */}
                <div className="absolute w-full h-full backface-hidden bg-indigo-500 text-white rounded-xl shadow-md flex items-center justify-center p-6 rotate-y-180">
                    <p className="text-lg text-center">{card.respuesta}</p>
                </div>
            </div>
        </div>
    );
};


const FlashcardGenerator: React.FC = () => {
    const [topic, setTopic] = useState('');
    const [flashcards, setFlashcards] = useState<Flashcard[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleGenerate = useCallback(async () => {
        if (!topic.trim()) {
            setError("Por favor, introduce un tema.");
            return;
        }
        setIsLoading(true);
        setError(null);
        setFlashcards([]);
        try {
            const result = await generateFlashcards(topic);
            setFlashcards(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : "Ocurrió un error desconocido.");
        } finally {
            setIsLoading(false);
        }
    }, [topic]);

    return (
        <Card className="w-full max-w-4xl mx-auto">
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
                <input
                    type="text"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    placeholder="Ej: La Revolución Francesa"
                    className="flex-grow p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition"
                    disabled={isLoading}
                />
                <button
                    onClick={handleGenerate}
                    disabled={isLoading || !topic.trim()}
                    className="bg-indigo-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-indigo-700 transition-colors disabled:bg-indigo-300 disabled:cursor-not-allowed"
                >
                    {isLoading ? "Generando..." : "Generar Flashcards"}
                </button>
            </div>

            {error && <p className="text-red-500 text-center my-4">{error}</p>}
            
            {isLoading && <Spinner />}

            {flashcards.length > 0 && (
                <div className="mt-8">
                    <h3 className="text-2xl font-bold text-slate-700 mb-6 text-center">Toca una tarjeta para voltearla</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {flashcards.map((card, index) => (
                            <FlashcardView key={index} card={card} />
                        ))}
                    </div>
                </div>
            )}
        </Card>
    );
};


// Add custom CSS for the 3D effect
const style = document.createElement('style');
style.textContent = `
  .perspective-1000 { perspective: 1000px; }
  .transform-style-3d { transform-style: preserve-3d; }
  .rotate-y-180 { transform: rotateY(180deg); }
  .backface-hidden { backface-visibility: hidden; -webkit-backface-visibility: hidden; }
`;
document.head.appendChild(style);


export default FlashcardGenerator;
